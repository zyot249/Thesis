# Thesis Report
## Title: A Template for Graduation Thesis for ICT Students
Author: Duc-Cuong Dao

School of Information and Communication Technology

Hanoi University of Science and Technology

--------------------------------------------

**Quick guide** (I'll update full guide as soon as possible)
- Setup your thesis information (your name, title, supervisor, etc.) on `Preamble/info.tex`
- Compile by executing the following commands
```
latex thesis.tex
bibtex thesis.aux
latex thesis.tex
latex thesis.tex
pdflatex thesis.tex -- To produce PDF file
```
